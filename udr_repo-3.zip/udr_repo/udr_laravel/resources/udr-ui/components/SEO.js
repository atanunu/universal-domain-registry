import Head from 'next/head'

/**
 * SEO component encapsulating common meta tags for search engines and social media.
 *
 * Accepts title, description and url props and outputs relevant tags for
 * canonical, Open Graph and Twitter cards. A default image from the public
 * folder is used for social previews. You can override it by passing a
 * `image` prop. If you need additional meta tags (e.g. keywords), extend
 * this component accordingly.
 */
export default function SEO({ title, description, url, image }) {
  const imageUrl = image || '/images/hero-modern.png'
  return (
    <Head>
      <title>{title}</title>
      <meta name="description" content={description} />
      <link rel="canonical" href={url} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={url} />
      <meta property="og:image" content={imageUrl} />
      <meta property="og:type" content="website" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={imageUrl} />
    </Head>
  )
}