import '@/styles/globals.css'
import { TranslationProvider } from '@/utils/TranslationContext'
import Head from 'next/head'

/**
 * Custom App component to wrap all pages with the TranslationProvider and
 * provide global meta tags. A viewport meta tag is added here to improve
 * responsiveness and accessibility across devices. Additional global tags can
 * be included here if required.
 */
export default function MyApp({ Component, pageProps }) {
  return (
    <>
      <Head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <TranslationProvider>
        <Component {...pageProps} />
      </TranslationProvider>
    </>
  )
}