import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import SEO from '@/components/SEO'
import { useTranslation } from '@/utils/TranslationContext'

/**
 * About page explaining the mission and values of UDR.
 */
export default function About() {
  const { t } = useTranslation()
  return (
    <>
      <SEO
        title={t.seo.about.title}
        description={t.seo.about.description}
        url="https://udr.org.yt/about"
      />
      <Navbar />
      <main className="max-w-5xl mx-auto py-16 px-4">
        <h1 className="text-4xl font-bold mb-6 text-gray-800">{t.about.title}</h1>
        <p className="text-gray-700 leading-relaxed mb-6 text-lg" dangerouslySetInnerHTML={{ __html: t.about.content }} />
        <h2 className="text-2xl font-semibold mb-4">Our Values</h2>
        <ul className="list-disc list-inside space-y-2 text-gray-700">
          <li>Integrity – we operate for the public benefit and maintain trustworthy records.</li>
          <li>Security – safeguarding the namespace and ensuring reliable DNS services.</li>
          <li>Innovation – embracing new technologies to serve our community better.</li>
          <li>Inclusivity – providing multilingual support and accessible registration.</li>
        </ul>
      </main>
      <Footer />
    </>
  )
}