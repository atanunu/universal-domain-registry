import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import SEO from '@/components/SEO'
import { useTranslation } from '@/utils/TranslationContext'

/**
 * Information for potential registrars, outlining responsibilities and how to join.
 */
export default function Registrars() {
  const { t } = useTranslation()
  return (
    <>
      <SEO
        title={t.seo.registrars.title}
        description={t.seo.registrars.description}
        url="https://udr.org.yt/registrars"
      />
      <Navbar />
      <main className="max-w-4xl mx-auto py-16 px-4">
        <h1 className="text-4xl font-bold mb-6 text-gray-800">{t.registrars.title}</h1>
        <p className="text-gray-700 leading-relaxed mb-6 text-lg" dangerouslySetInnerHTML={{ __html: t.registrars.content }} />
        <p className="text-gray-700 mb-2">As a registrar you will:</p>
        <ul className="list-disc list-inside space-y-1 text-gray-700 mb-6">
          <li>Facilitate sub‑domain registrations on behalf of customers.</li>
          <li>Ensure unique assignments of names and handle IP address mapping.</li>
          <li>Adhere to UDR’s policies on names, privacy and dispute resolution.</li>
          <li>Provide support to registrants throughout the lifecycle of their domains.</li>
        </ul>
        <p className="text-gray-700">
          If you’re ready to start the onboarding process, send us an email at{' '}
          <a href="mailto:registrars@udr.org.yt" className="text-primary hover:underline">registrars@udr.org.yt</a>.
        </p>
      </main>
      <Footer />
    </>
  )
}