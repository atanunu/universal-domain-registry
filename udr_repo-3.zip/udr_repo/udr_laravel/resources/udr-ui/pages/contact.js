import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import SEO from '@/components/SEO'
import { useTranslation } from '@/utils/TranslationContext'

/**
 * Contact page with a simple form. The form does not submit anywhere by
 * default, but it demonstrates how a contact section could look.
 */
export default function Contact() {
  const { t } = useTranslation()
  return (
    <>
      <SEO
        title={t.seo.contact.title}
        description={t.seo.contact.description}
        url="https://udr.org.yt/contact"
      />
      <Navbar />
      <main className="max-w-3xl mx-auto py-16 px-4">
        <h1 className="text-4xl font-bold mb-6 text-gray-800">{t.contact.title}</h1>
        <p className="text-gray-700 leading-relaxed mb-6 text-lg">{t.contact.content}</p>
        <form
          onSubmit={(e) => {
            e.preventDefault()
            alert('Thank you for contacting us!')
          }}
          className="space-y-4"
        >
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700">
              Name
            </label>
            <input
              id="name"
              type="text"
              required
              className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-primary focus:border-primary"
            />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
              Email
            </label>
            <input
              id="email"
              type="email"
              required
              className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-primary focus:border-primary"
            />
          </div>
          <div>
            <label htmlFor="message" className="block text-sm font-medium text-gray-700">
              Message
            </label>
            <textarea
              id="message"
              rows="5"
              required
              className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-primary focus:border-primary"
            ></textarea>
          </div>
          <button
            type="submit"
            className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors"
          >
            Send
          </button>
        </form>
      </main>
      <Footer />
    </>
  )
}