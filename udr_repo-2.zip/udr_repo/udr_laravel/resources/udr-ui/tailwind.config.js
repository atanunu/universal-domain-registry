/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}'
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#0066ff',
          dark: '#0052cc',
        },
        secondary: {
          DEFAULT: '#00bfa5',
          dark: '#008e76',
        },
      },
    },
  },
  plugins: [],
}