import { createContext, useContext } from 'react'
import { useRouter } from 'next/router'
import en from '../locales/en.json'
import fr from '../locales/fr.json'

/**
 * Provides translation messages based on the current locale. The Next.js
 * configuration defines available locales and a default. When the locale
 * changes, this provider selects the appropriate message dictionary.
 */
const TranslationContext = createContext({ t: en })

export function TranslationProvider({ children }) {
  const { locale } = useRouter()
  const messages = locale === 'fr' ? fr : en
  return (
    <TranslationContext.Provider value={{ t: messages }}>
      {children}
    </TranslationContext.Provider>
  )
}

export function useTranslation() {
  return useContext(TranslationContext)
}