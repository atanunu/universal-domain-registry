import { useState } from 'react'
import { useTranslation } from '@/utils/TranslationContext'

/**
 * Domain search form that simulates availability. Names shorter than three
 * characters are considered unavailable; longer names are available. Replace
 * this with an actual RDAP/WHOIS lookup for production.
 */
export default function DomainSearch() {
  const { t } = useTranslation()
  const [name, setName] = useState('')
  const [result, setResult] = useState(null)

  const checkAvailability = (e) => {
    e.preventDefault()
    if (!name) return
    const available = name.length >= 3
    setResult(available ? 'available' : 'unavailable')
  }

  return (
    <form onSubmit={checkAvailability} className="max-w-xl mx-auto w-full">
      <label htmlFor="domain" className="block text-sm font-medium text-gray-700 mb-1">
        {t.search.label}
      </label>
      <div className="flex">
        <input
          id="domain"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder={t.search.placeholder}
          className="flex-grow px-4 py-2 border border-gray-300 rounded-l focus:outline-none focus:ring-primary focus:border-primary"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-primary text-white rounded-r hover:bg-primary-dark transition-colors"
        >
          {t.search.button}
        </button>
      </div>
      {result && (
        <p
          className={`mt-4 text-sm font-medium text-center ${
            result === 'available' ? 'text-green-600' : 'text-red-600'
          }`}
        >
          {result === 'available' ? t.search.available : t.search.unavailable}
        </p>
      )}
    </form>
  )
}