import '@/styles/globals.css'
import { TranslationProvider } from '@/utils/TranslationContext'

export default function MyApp({ Component, pageProps }) {
  return (
    <TranslationProvider>
      <Component {...pageProps} />
    </TranslationProvider>
  )
}