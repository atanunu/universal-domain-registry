import { useTranslation } from '@/utils/TranslationContext'

/**
 * Basic footer with a copyright notice. Pulls text from translations.
 */
export default function Footer() {
  const { t } = useTranslation()
  return (
    <footer className="bg-gray-50 border-t border-gray-200 py-6 mt-16">
      <div className="max-w-7xl mx-auto px-4 text-center text-sm text-gray-600">
        <p>{t.footer.rights}</p>
      </div>
    </footer>
  )
}