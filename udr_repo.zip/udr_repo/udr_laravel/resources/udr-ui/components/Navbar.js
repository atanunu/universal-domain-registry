import Link from 'next/link'
import { useRouter } from 'next/router'
import { useTranslation } from '@/utils/TranslationContext'

/**
 * Navigation bar with links and a language toggle. Uses Next.js routing to
 * change locales without reloading the page.
 */
export default function Navbar() {
  const { t } = useTranslation()
  const router = useRouter()
  const { locale, asPath } = router
  const otherLocale = locale === 'en' ? 'fr' : 'en'

  const handleLocaleSwitch = () => {
    router.push(asPath, asPath, { locale: otherLocale })
  }

  return (
    <nav className="bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto flex items-center justify-between py-4 px-4">
        <Link href="/" locale={locale} className="font-bold text-primary text-xl">
          UDR
        </Link>
        <div className="space-x-6 hidden sm:flex">
          <Link href="/" locale={locale} className="hover:text-primary-dark">
            {t.nav.home}
          </Link>
          <Link href="/about" locale={locale} className="hover:text-primary-dark">
            {t.nav.about}
          </Link>
          <Link href="/registrars" locale={locale} className="hover:text-primary-dark">
            {t.nav.registrars}
          </Link>
          <Link href="/contact" locale={locale} className="hover:text-primary-dark">
            {t.nav.contact}
          </Link>
        </div>
        <button
          onClick={handleLocaleSwitch}
          className="ml-4 text-sm border px-3 py-1 rounded border-primary text-primary hover:bg-primary hover:text-white transition-colors"
        >
          {t.footer.switchLocale}
        </button>
      </div>
    </nav>
  )
}