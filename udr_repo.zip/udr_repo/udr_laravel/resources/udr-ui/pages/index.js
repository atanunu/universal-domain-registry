import Image from 'next/image'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import DomainSearch from '@/components/DomainSearch'
import { useTranslation } from '@/utils/TranslationContext'

/**
 * Home page introducing UDR with a hero section and search form.
 */
export default function Home() {
  const { t } = useTranslation()
  return (
    <>
      <Navbar />
      <section className="relative bg-gray-900 text-white flex items-center justify-center min-h-[60vh] overflow-hidden">
        <Image
          src="/images/hero.png"
          alt="Network background"
          fill
          className="object-cover opacity-60"
          priority
        />
        <div className="relative z-10 text-center px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            {t.hero.title}
          </h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
            {t.hero.subtitle}
          </p>
          <div className="max-w-lg mx-auto">
            <DomainSearch />
          </div>
        </div>
      </section>
      <section className="py-16 px-4 bg-white">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-2xl font-semibold mb-4">
            {t.about.title}
          </h2>
          <p className="text-gray-700 leading-relaxed" dangerouslySetInnerHTML={{ __html: t.about.content }} />
        </div>
      </section>
      <Footer />
    </>
  )
}